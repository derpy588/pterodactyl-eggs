console.log('\n_________  __      __  _________\n\\_   ___ \\\/  \\    \/  \\\/   _____\/\n\/    \\  \\\/\\   \\\/\\\/   \/\\_____  \\ \n\\     \\____\\        \/ \/        \\\n \\______  \/ \\__\/\\  \/ \/_______  \/\n        \\\/       \\\/          \\\/ \n');
console.log('Bienvenue sur votre serveur d\'hébergement NodeJS');
console.log('Merci d\'avoir fait confiance à chaun14 Web Services');
console.log('>> Pour installer votre bot, connectez vous au serveur en SFTP');
console.log('                                            ');                                                                                                              

process.stdin.resume();